#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define PORT "3490"
#define BACKLOG 10
#define MAX_CLIENTS 30
#define MAX_LENGTH 30

void* get_in_addr(struct sockaddr *sa){
    if(sa->sa_family==AF_INET){
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }
    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int search(int *arr,int key,int size){
	
	for(int i=0;i<size;i++){
		
		if(arr[i]==key){
			
			return i;
			
		}
	}
	
	return -1;
}

int main(){


    char str[MAX_CLIENTS][MAX_LENGTH];
    
    strcpy(str[0], "rohit");
    strcpy(str[1], "gill");
    strcpy(str[2], "kohli");
    strcpy(str[3], "iyer");
    strcpy(str[4], "hardik");
    strcpy(str[5], "rahul");
    strcpy(str[6], "washi");
    strcpy(str[7], "jaddu");
    strcpy(str[8], "chahal");
    strcpy(str[9], "boom");
    strcpy(str[10], "shami");


    int clientfd[MAX_CLIENTS];
    
    for(int i=0;i<MAX_CLIENTS;i++){	
    	clientfd[i]=0;
    }
    
    fd_set master;
    fd_set read_fds;
    int fd_max;

    int listener;
    int new_fd;
    struct sockaddr_storage remoteaddr;
    socklen_t addr_len;
    
    

    char buf[256];
    int nbytes;

    char remote[INET6_ADDRSTRLEN];

    int yes=1;
    int i,j,rv;


    struct addrinfo hints,*ai,*p;

    FD_ZERO(&master);
    FD_ZERO(&read_fds);

    memset(&hints,0,sizeof(hints));
    hints.ai_family=AF_UNSPEC;
    hints.ai_socktype=SOCK_STREAM;
    hints.ai_flags=AI_PASSIVE;

    if((rv=getaddrinfo(NULL,PORT,&hints,&ai))!=0){

        fprintf(stderr,"selectserver: %s\n",gai_strerror(rv));
        exit(1);

    }

    for(p=ai;p!=NULL;p=p->ai_next){
    
        listener=socket(p->ai_family,p->ai_socktype,p->ai_protocol);
        if(listener<0)continue;

        setsockopt(listener,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int));
        
        
        if(bind(listener,p->ai_addr,p->ai_addrlen)<0){
            close(listener);
            continue;
        }

        break;
    }

    if(p==NULL){

        fprintf(stderr,"selectserver :failed to bind\n");
        exit(2);

    }

    freeaddrinfo(ai);

    if(listen(listener,BACKLOG)==-1){
        perror("listen");
        exit(3);
    }

    FD_SET(listener,&master);

    fd_max=listener;

    
    for(;;){
        read_fds=master;

        if(select(fd_max+1,&read_fds,NULL,NULL,NULL)==-1){
            perror("select");
            exit(4);
        }

        for(i=0;i<=fd_max;i++){
            if(FD_ISSET(i,&read_fds)){
                if(i==listener){
                    addr_len=sizeof remoteaddr;
                    new_fd=accept(listener,(struct sockaddr*)&remoteaddr,&addr_len);

		    
                    if(new_fd==-1){
                        perror("accept");
                    }
                    else{
                    
                        for(int k=0;k<MAX_CLIENTS;k++){
		    	
		    	    if(clientfd[k]==0){
		    		
		    		   clientfd[k]=new_fd;
		    		   break;
		    		
		    	    }
		    	    else if(clientfd[k]!=0 && clientfd[k]==new_fd){
		    		
		    		   break;
		    	
		    	    }
		      
		        }
                    	
                        FD_SET(new_fd,&master);

                        if(new_fd>fd_max){
                            fd_max=new_fd;
                        }
			
			
                        printf("%s joined the chat\n",str[search(clientfd,new_fd,30)]);

                        
                    }
                }

                else{
                
                
                    for(int k=0;k<MAX_CLIENTS;k++){
                    	
                    	if(clientfd[k]!=0) {
                    	
                    		if(i==clientfd[k])break;
                    	}
                    	else{
                    	
                    		clientfd[k]=i;
                    		break;
                    		
                    	}
                    	
                    }

                    if((nbytes =recv(i,buf,sizeof buf,0))<=0){

                        if(nbytes==0){

                            printf("%s exited\n",str[search(clientfd,i,30)]);

                        }
                        else{

                            perror("recv");

                        }

                        close(i);
                        FD_CLR(i,&master);

                    }
                    else{
                    
                    
                        char msg[MAX_LENGTH];
                        msg[0]='\0';
                        
                        if(strcmp(buf,"/exit")==0 || strcmp(buf,"/part")==0 || strcmp(buf,"/quit")==0){
		    
		    	    send(i , buf , strlen(buf) ,0);
		    	    strcat(msg , str[search(clientfd,i,30)] );
		    	    strcat(msg ," exited the chat");
		    	    
		    	    
		        }
		        else{
		        
		        	printf("%s send this message :",str[search(clientfd,i,30)]);
		        	
		        	printf("%s\n",buf);
		        	
		        	strcat(msg ,str[search(clientfd,i,30)]);
		        	strcat(msg ," : ");
		        	strcat(msg ,buf );
		        	
		        }

                        for(j=0;j<=fd_max;j++){

                            if(FD_ISSET(j,&master)){

                                if(j!=listener && j!=i){

                                    if(send(j,msg,strlen(msg),0)==-1){
                                        perror("send");
                                    }

                                }

                            }

                         }
                     }
                     
                     memset(buf,0,MAX_LENGTH);
                
                }
             }
         }
     }
     return 0;
}
